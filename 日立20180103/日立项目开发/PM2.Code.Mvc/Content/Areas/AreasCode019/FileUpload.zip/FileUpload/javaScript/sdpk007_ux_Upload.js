﻿

(function ($) {

    var me = null;
    var isLoad = false;
    var _pk = "-1";

    //#region Init
    var sdpk007_ux_Grid;
    var sdpk007_ux_AddBt, sdpk007_ux_ReadBt, sdpk007_ux_DelBt;
    //#endregion

    //#region ctor
    var sdpk007_ux_WinClass = function () {
        me = this;
        //#region Init
        sdpk007_ux_Grid = $('#sdpk007_ux_Grid');
        sdpk007_ux_AddBt = $('#sdpk007_ux_AddBt');
        sdpk007_ux_ReadBt = $('#sdpk007_ux_ReadBt');
        sdpk007_ux_DelBt = $('#sdpk007_ux_DelBt');
        //#endregion
        //#region 附件新增
        sdpk007_ux_AddBt.linkbutton({
            onClick: function () {
                if (me.pk == "-1"){
                    $.messager.alert('提示信息', '请设置关联单据主键!', 'warning');
                    return;
                }
                window.open('/AreasCode019/FileUpload/ChildAction/'+ me.pk);

            }
        });
        //#endregion
        //#region 附件删除
        sdpk007_ux_DelBt.linkbutton({
            onClick: function () {
                var records = sdpk007_ux_Grid.datagrid('getChecked');
                if (records && records.length > 0) {

                    var pa00801s = [];
                    $.each(records, function (index, record) {
                        pa00801s.push(record.pk);
                    });
                    
                    $.ajax({
                        type: "POST",
                        url: "/AreasCode019/sdpk007/Remove",
                        contentType: "application/json; charset=utf-8",
                        data: JSON.stringify(pa00801s),
                        dataType: "json",
                        success: function (data) {
                            if (data.success) {
                                $.each(pa00801s, function (index, pk) {
                                    var index = sdpk007_ux_Grid.datagrid('getRowIndex', pk);
                                    sdpk007_ux_Grid.datagrid('deleteRow', index);
                                });

                            } else {
                                $.messager.alert('友情提示', data.Message, 'error');
                            }
                        },
                        error: function (data) {

                        }
                    });

                }else
                    $.messager.alert('提示信息', '请选择要删除的数据!', 'warning');

            }
        });
        //#endregion
        //#region 查看附件
        sdpk007_ux_ReadBt.linkbutton({
            onClick: function () {
               
            }
        });
        //#endregion
        Init();

    };
    //#endregion

    var Init = function () {
        //#region sdpk007_ux_Grid_Init
        sdpk007_ux_Grid.datagrid({
            idField: 'pk',
            fit: true,
            border: false,

            url: '/AreasCode019/sdpk007/GetModels',
            loadMsg: '数据加载中,请稍后...',
            method: 'post',
            rownumbers: true,
            singleSelect: true,
            checkOnSelect: false,
            selectOnCheck: false,

            pagination: true,
            pageSize: 100,
            pageList: [100],
            columns: [[
                { field: "ck", checkbox: true },
                { field: 'pk00803', title: '附件名称', width: 300 },
                { field: 'pk00805', title: '创建时间', width: 180, align: 'center' },
                { field: 'pj00402', title: '创建人', width: 130 }

            ]],
            onDblClickRow: function (rowIndex, record) {
                me.onGrid_Click(rowIndex, record);
                me.Win_Close();
            },
            onBeforeLoad: function (param) {
                return isLoad;
            }
        });
        var pager = sdpk007_ux_Grid.datagrid('getPager');
        pager.pagination({
            //total: 100,
            showPageList: false,
            layout: ['list', 'sep', 'first', 'prev', 'links', 'next', 'last', 'sep', 'refresh'],
            displayMsg: "当前页从 {from} 到 {to} 条记录.共 {total} 条记录."
        });
        //#endregion
        
    }
    sdpk007_ux_WinClass.prototype = {
        //单据主键
        pk: "-1",
        SetPK: function (pk) {
            me.pk = pk;
        },
        Init: function (pk, isEnable) {
            me.pk = pk;
            var x = 'enable';
            if (!isEnable)
                x = 'disable';
            sdpk007_ux_AddBt.linkbutton(x);
            sdpk007_ux_DelBt.linkbutton(x);

        },
        //#region Grid
        //#region 附件添加
        Add: function (_row) {
            sdpk007_ux_Grid.datagrid('appendRow', _row);
            return me;
        },
        //#endregion
        //#region 加载
        Load: function () {
            isLoad = true;
            sdpk007_ux_Grid.datagrid('load', {
                pk: me.pk
            });
            return me;
        },
        //#endregion
        //#region 双击
        onGrid_Click: function (rowIndex, record) { },
        //#endregion
        //#endregion
    }

    window.sdpk007uxWinClass = null;
    $(document).ready(function (e) {
        window.sdpk007uxWinClass = new sdpk007_ux_WinClass();
    });

})(jQuery);
